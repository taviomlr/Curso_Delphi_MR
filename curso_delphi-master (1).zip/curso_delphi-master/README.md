# Curso de Delphi
Desenvolver Sistema com Delphi e SQL-Server na PRÁTICA

https://www.udemy.com/course/desenvolver-sistema-com-delphi-e-sql-server-na-pratica/
